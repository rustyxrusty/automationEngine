const { app } = require('@azure/functions');

require('./functions/syncCompany');
require('./functions/testApiKey');


app.setup({
    enableHttpStream: true,
});
